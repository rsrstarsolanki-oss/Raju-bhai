package com.raju.aiassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chat = findViewById(R.id.chat)
        input = findViewById(R.id.input)
        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.send).setOnClickListener { reply(input.text.toString()) }
        findViewById<Button>(R.id.mic).setOnClickListener { startVoice() }
    }

    private fun reply(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return

        val answer = when {
            q.contains("hello", true) || q.contains("hi", true) ||
            q.contains("namaste", true) -> "Namaste! Main Raju hoon 😎"
            q.contains("naam", true) -> "Mera naam AI Raju hai."
            q.contains("time", true) -> "Abhi phone ka current time dekhne ke liye clock app use kar sakte ho."
            q.contains("help", true) -> "Main abhi basic chat aur voice input/output support karta hoon."
            else -> "Samajh gaya 😄 Main AI Raju hoon. Is basic version me offline responses hain."
        }

        chat.append("\n\nTum: $q\nRaju: $answer")
        input.text.clear()
        if (::tts.isInitialized) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "raju")
    }

    private fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Raju ko bolo...")
        }
        try { startActivityForResult(intent, 101) }
        catch (_: Exception) { Toast.makeText(this, "Voice input available nahi hai.", Toast.LENGTH_SHORT).show() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (text != null) reply(text)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
